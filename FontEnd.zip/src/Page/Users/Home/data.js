export default {
    Mainurl: "http://localhost:3022",
    IMG : 'http://localhost:3022/profile/',

    GETSL: '/v3/slide/get',
    GETTP: '/v1/pro_type/get',
    GETITEMS: '/v2/items/get'
}
export default {
    Mainurl: "http://localhost:3022",
    IMG : 'http://localhost:3022/profile/',

    POST: '/v2/items/add',
    GET: '/v2/items/get',
    DEL: '/v2/items/',

    GETTYPE: '/v1/pro_type/get',

}
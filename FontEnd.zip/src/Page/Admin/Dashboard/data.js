export default {
    Mainurl: "http://localhost:3022",

    get: '/v1/pro_type/get',
    GETUsers: '/Login/GetLogin',
    GETITEMS: '/v2/items/get'
}
export default {
    Mainurl: "http://localhost:3022",

    POST: '/v1/pro_type/add',
    get: '/v1/pro_type/get',
    put: '/v1/pro_type/put/',
    del: '/v1/pro_type/del/',
}
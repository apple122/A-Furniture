export default {
    Mainurl: "http://localhost:3022",
    IMG : 'http://localhost:3022/profile/',

    POST: '/v3/slide/add',
    GET: '/v3/slide/get',
    DEL: '/v3/slide/'
}
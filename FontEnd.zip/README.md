# ວີທີຕິດຕັ້ງໂປຣເຈັກ

Furnituer ພາສາທີ່ໃຊ້ພັດທະນາເວັບ ReactJS and tailwindcss

ກ່ອນອືນໃຫ້ Copy URL ນີ້ໄປ Clone

    https://github.com/apple122/A-Furniture.git

ຫຼັງຈາກນັ້ນສ້າງ Folder ໄວ້ເກັບໂປຣເຈັກ ແລ້ວເຂົ້າຫາ Folder ນີ້ດ້ວຍ Terminal ຫຼື CMD
ພີມຕາມນີ້ git clone ຕາມດ້ວຍ url

    git clone https://github.com/apple122/A-Furniture.git
    
ກົດ Enter ລໍຖ້າມັນຕິດຕັ້ງແລ້ວ ຫຼັງຈາກນັ້ນເຂົ້າຫາໂປຣເຈັກນີ້ດ້ວຍ VScode Visual Studio Code
ຫຼັງຈາດນັ້ນເປິດ terminal Visual Studio Code ຂອງໂປຣເຈັກນີ້ຂື້ນມາ ແລ້ວຕິດຕັ້ງຕາມນີ້

Install Dependency / ຕິດຕັ້ງ

    npm install

Run app / ເປິດແອັບ

    npm start

# ສີ້ນສຸດ
